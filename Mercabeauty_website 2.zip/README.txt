# Mercabeauty — site gratuit

## Mise en ligne en 0 DH
1. Ouvre `index.html` dans ton navigateur pour tester le site.
2. Remplace `212600000000` dans le fichier par ton vrai numéro WhatsApp (sans +).
3. Pour mettre le site en ligne gratuitement, tu peux utiliser GitHub Pages, Cloudflare Pages ou Vercel.
4. Les cartes produits contiennent actuellement les prix fournis pour Mercabeauty. Modifie le tableau `products` dans `index.html` si tes prix changent.
5. Les visuels produits sont des placeholders élégants. Tu peux remplacer les blocs `.mini-bottle` par tes vraies photos.

## Important
Le site ne prend pas de paiement en ligne : le panier prépare une commande WhatsApp.
